pip install virtualenv
pip install pyinstaller
virtualenv venv
.\venv\Scripts\activate.ps1
pyinstaller main.py --onefile --name dtfolder.exe --windowed
